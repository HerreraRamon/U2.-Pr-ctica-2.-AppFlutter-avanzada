import 'package:flutter/material.dart';
class logico extends StatefulWidget {
  const logico({Key? key}) : super(key: key);

  @override
  State<logico> createState() => _logicoState();
}

class _logicoState extends State<logico> {
  final TextEditingController num1Controller = TextEditingController();
  final TextEditingController num2Controller = TextEditingController();
  final TextEditingController resultController = TextEditingController();
  void and() {
    bool num1 = num1Controller.text.toLowerCase() == 'true';
    bool num2 = num2Controller.text.toLowerCase() == 'true';
    bool resultado = num1 && num2;
    resultController.text = resultado.toString();
  }

  void or() {
    bool num1 = num1Controller.text.toLowerCase() == 'true';
    bool num2 = num2Controller.text.toLowerCase() == 'true';
    bool resultado = num1 || num2;
    resultController.text = resultado.toString();
  }

  void xor() {
    bool num1 = num1Controller.text.toLowerCase() == 'true';
    bool num2 = num2Controller.text.toLowerCase() == 'true';
    bool resultado = num1 ^ num2;
    resultController.text = resultado.toString();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          TextField(
            controller: num1Controller,
            decoration: InputDecoration(
              hintText: 'Ingrese true o false',
            ),
          ),
          TextField(
            controller: num2Controller,
            decoration: InputDecoration(
              hintText: 'Ingrese true o false',
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              ElevatedButton(
                onPressed: and,
                child: Text('AND'),
              ),
              ElevatedButton(
                onPressed: or,
                child: Text('OR'),
              ),
              ElevatedButton(
                onPressed: xor,
                child: Text('XOR'),
              ),
            ],
          ),
          TextField(
            controller: resultController,
            enabled: false,
            decoration: InputDecoration(
              hintText: 'Resultado',
            ),
          ),
        ],
      ),
    );
  }
}
