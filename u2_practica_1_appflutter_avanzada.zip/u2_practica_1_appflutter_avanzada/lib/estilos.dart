import 'package:flutter/material.dart';
class estilos extends StatefulWidget {
  const estilos({Key? key}) : super(key: key);

  @override
  State<estilos> createState() => _estilosState();
}

class _estilosState extends State<estilos> {
  Color _textColor = Colors.black;
  List<Color> colores=[Colors.red,Colors.green,Colors.blue];
  int _indiceC=0;

  int _indiceS=0;
  List<double> _Sizes = [10.0,20.0,30.0];
  double _fontSize=20.0;

  bool _isBold = false;

  void _cambiarIndiceC(int ind){
    setState(() {
      _indiceC+=1 ;
      print(_indiceC);
      if(_indiceC>=3)_indiceC=0;

      _Color(colores[_indiceC] as Color);
    });
  }
  void _cambiarIndiceS(int ind){
    setState(() {
      _indiceS+=1 ;
      print(_indiceS);
      if(_indiceS>=3)_indiceS=0;

      _Size(_Sizes[_indiceS]);
    });
  }
  void _Size(double size) {
    setState(() {
      _fontSize = size;
    });
  }

  void _Bold() {
    setState(() {
      _isBold = !_isBold;
    });
  }

  void _Color(Color color) {
    setState(() {
      _textColor = color;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Ing. Herrera Herrera Ramon',
              style: TextStyle(
                fontSize: _Sizes[_indiceS],
                fontWeight: _isBold ? FontWeight.bold : FontWeight.normal,
                color: _textColor,
              ),
            ),
            SizedBox(height: 20.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                ElevatedButton(
                  onPressed: () => _cambiarIndiceS(_indiceS),
                  child: Text('Tamaño'),
                ),
                ElevatedButton(
                  onPressed: _Bold,
                  child: Text(_isBold ? 'Normal' : 'Bold'),
                ),
              ],
            ),
            SizedBox(height: 20.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                ElevatedButton(
                  onPressed: () => _cambiarIndiceC(_indiceC),
                  child: Text('Cambiar color'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
