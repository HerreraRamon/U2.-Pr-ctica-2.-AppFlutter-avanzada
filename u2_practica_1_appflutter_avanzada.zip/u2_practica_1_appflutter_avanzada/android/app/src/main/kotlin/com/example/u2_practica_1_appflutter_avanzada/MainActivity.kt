package com.example.u2_practica_1_appflutter_avanzada

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
