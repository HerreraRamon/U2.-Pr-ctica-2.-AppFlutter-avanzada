import 'package:flutter/material.dart';
import 'aritmetico.dart';
import 'logico.dart';
import 'estilos.dart';
class Practica2 extends StatefulWidget {
  const Practica2({Key? key}) : super(key: key);

  @override
  State<Practica2> createState() => _Practica2State();
}

class _Practica2State extends State<Practica2> {
  int _indice=0;
  int resultado=0;
  void _cambiarIndice(int indice){
    setState((){
      _indice=indice;
    });
  }
  final List<Widget> _paginas=[
    aritmetico(),
    logico(),
    estilos(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Aplicacion 2"),
      ),
      body:_paginas[_indice],
      bottomNavigationBar:BottomNavigationBar(
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.add_chart_rounded), label: "aritmetica"),
          BottomNavigationBarItem(icon: Icon(Icons.accessibility),label: "logico"),
          BottomNavigationBarItem(icon: Icon(Icons.edit),label: "estilo"),
        ],
        onTap: _cambiarIndice,
      ),
    );
  }
}
