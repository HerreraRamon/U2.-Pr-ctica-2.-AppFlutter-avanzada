import 'package:flutter/material.dart';
class aritmetico extends StatefulWidget {
  const aritmetico({Key? key}) : super(key: key);

  @override
  State<aritmetico> createState() => _aritmeticoState();
}

class _aritmeticoState extends State<aritmetico> {
  final TextEditingController num1Controller = TextEditingController();
  final TextEditingController num2Controller = TextEditingController();
  final TextEditingController resultController = TextEditingController();
  int _resultado=0;
  void res(int resultado){
    _resultado=resultado;
  }
  void sumar() {
    double num1 = double.parse(num1Controller.text);
    double num2 = double.parse(num2Controller.text);
    double _resultado = num1 + num2;
    resultController.text = _resultado.toString();
  }

  void restar() {
    double num1 = double.parse(num1Controller.text);
    double num2 = double.parse(num2Controller.text);
    double _resultado = num1 - num2;
    resultController.text = _resultado.toString();
  }
  void multiplicar() {
    double num1 = double.parse(num1Controller.text);
    double num2 = double.parse(num2Controller.text);
    double resultado = num1 * num2;
    resultController.text = resultado.toString();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          TextField(
            controller: num1Controller,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              hintText: 'Ingrese un número',
            ),
          ),
          TextField(
            controller: num2Controller,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              hintText: 'Ingrese otro número',
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              ElevatedButton(
                onPressed: sumar,
                child: Text('Sumar'),
              ),
              ElevatedButton(
                onPressed: restar,
                child: Text('Restar'),
              ),
              ElevatedButton(
                onPressed: multiplicar,
                child: Text('Multiplicar'),
              ),
            ],
          ),
          TextField(
            controller: resultController,
            enabled: false,
            decoration: InputDecoration(
              hintText: 'Resultado',
            ),
          ),
        ],
      ),
    );
  }
}

